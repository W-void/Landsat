BatchFMQuadraticNode
$$
Z_i = \sum_{l=0}^n \left( \sum_{j=0} \sum_{k=j+1} V_{ij} V_{ik} X_{ij} X_{ik} \right)_l
$$
BatchGroupFMQuadraticNode
$$
Z_i = \sum_{l=0}^n \left(\sum_{j=0}^m \sum_{k=j+1}^m X_{ij} X_{ik}\right)_l
$$
BatchGroupFMQuadratic2Node
$$
Z_i = \sum_{j=0}^m \sum_{k=j+1}^m X_{ij} X_{ik}
$$